﻿using Microsoft.AspNetCore.Mvc;
using SubmitClaims.Data;
using SubmitClaims.Models;
using SubmitClaims.Models.Entities;
using Microsoft.EntityFrameworkCore;


namespace SubmitClaims.Controllers
{
    public class ClaimController : Controller
    {
        private readonly ApplicationDbContext dbContext;

        public ClaimController(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        [HttpGet]
        public IActionResult Submit()
        {
            return View();
        }
       // [HttpPost]
       //// public async Task<IActionResult> Submit(SubmitClaimViewModel viewModel)
       //// {
       //    // var claim = new Claim
       //    // {
       //        // FirstName = viewModel.Name,
                
       //       //  HoursWorked = viewModel.HoursWorked,
       //        // RateHour = viewModel.RateHour,
       //        // TotalHours = viewModel.TotalHours,
       //         DescriptionOfWork = viewModel.DescriptionOfWork,
       //         SupportingDocuments = (List<IFormFile>)viewModel.SupportingDocuments
       //     };

       //     return View();
       // }
       // public async Task<IActionResult> PendingClaims()
       // {
       //     var pendingClaims = await DbContext.Claim
       //         .Where(c => c.Status == "Pending")
       //         .Select(c => new VerifyClaimViewModel
       //         {
       //             ClaimId = c.Id,
       //             LecturerName = c.LecturerName,
       //             HoursWorked = c.HoursWorked,
       //             HourlyRate = c.HourlyRate,
       //             Notes = c.Notes,
       //             Status = c.Status,
       //             DocumentPath = c.DocumentPath
       //         }).ToListAsync();

       //     return View(pendingClaims);
       // }
       // // Action to approve claim
       // [HttpPost]
       // public async Task<IActionResult> ApproveClaim(int id)
       // {
       //     var claim = await DbContext.Claims.FindAsync(id);
       //     if (claim != null)
       //     {
       //         claim.Status = "Approved";
       //         await DbContext.SaveChangesAsync();
       //     }

       //     return RedirectToAction("PendingClaims");
       // }

       // // Action to reject claim
       // [HttpPost]
       // public async Task<IActionResult> RejectClaim(int id)
       // {
       //     var claim = await DbContext.Claims.FindAsync(id);
       //     if (claim != null)
       //     {
       //         claim.Status = "Rejected";
       //         await DbContext.SaveChangesAsync();
       //     }

       //     return RedirectToAction("PendingClaims");
       // }
    }


}
    

