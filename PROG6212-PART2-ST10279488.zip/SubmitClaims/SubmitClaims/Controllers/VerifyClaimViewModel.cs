﻿namespace SubmitClaims.Controllers
{
    internal class VerifyClaimViewModel
    {
        public object ClaimId { get; set; }
        public object LecturerName { get; set; }
        public object HoursWorked { get; set; }
        public object HourlyRate { get; set; }
        public object Notes { get; set; }
        public object Status { get; set; }
        public object DocumentPath { get; set; }
    }
}