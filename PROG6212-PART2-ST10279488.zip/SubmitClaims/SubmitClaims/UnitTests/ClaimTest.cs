﻿namespace SubmitClaims.UnitTests
{
    public class ClaimTest
    {

    }
}
