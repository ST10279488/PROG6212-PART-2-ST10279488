﻿namespace SubmitClaims.Models
{
    public class VerifyClaimViewModel
    {
        
            public int ClaimId { get; set; }
            public required string LecturerName { get; set; }
            public double HoursWorked { get; set; }
            public decimal HourlyRate { get; set; }
            public required string Notes { get; set; }
            public required string Status { get; set; }
            public required string DocumentPath { get; set; }
        }

    }

