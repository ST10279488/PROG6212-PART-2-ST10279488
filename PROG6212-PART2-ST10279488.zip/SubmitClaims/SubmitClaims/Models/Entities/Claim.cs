﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SubmitClaims.Models.Entities
{
    public class Claim
    {
        public Guid Id { get; set; }

        [Required]
        public string LecturerID { get; set; }
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
        [Required]
        public DateTime ClaimsPeriodsStart { get; set; }
        [Required]
        public DateTime ClaimsPeriodsEnd { get; set; }
        [Required]
        public double HoursWorked { get; set; }
        [Required]
        public double RateHour { get; set; }
        [Required]
        public double TotalHours { get; set; }

        public required string DescriptionOfWork { get; set; }

        // Mark this property as NotMapped so EF doesn't try to map it to the database
        [NotMapped]
        public List<IFormFile> SupportingDocuments { get; set; }

        public required string Status { get; set; }
    }
}
