﻿namespace SubmitClaims.Models
{
    public class SubmitClaimViewModel
    {
        public required string Name { get; set; }
        public required string Email { get; set; }
        public double HoursWorked { get; set; }
        public double RateHour { get; set; }
        public double TotalHours { get; set; }
        public required string DescriptionOfWork { get; set; }
        public object? SupportingDocuments { get; internal set; }
    }
}
