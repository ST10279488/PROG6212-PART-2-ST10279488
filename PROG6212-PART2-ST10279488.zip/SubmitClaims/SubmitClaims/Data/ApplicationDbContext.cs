﻿using Microsoft.EntityFrameworkCore;
using SubmitClaims.Models.Entities;

namespace SubmitClaims.Data
{
    public class ApplicationDbContext: DbContext
    {
        internal object Claim;

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options): base(options)
        {
            
        }
        public DbSet<Claim> Lecturers { get; set; }
        public object Claims { get; internal set; }

    }
}
